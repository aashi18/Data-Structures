
#include"ll.cpp"
class sll: public ll
{
   public:
      sll();
      virtual ~sll();
      void push(int);
      int pop();
      bool isEmpty();
};
